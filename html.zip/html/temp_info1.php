<?php
require("db.php");
$mysqli1 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

if(!$mysqli1){
	die("Connection failed: " . $mysqli->error);
}

$plant=$_GET['plant'];
//query to get data from the table
$query1 = sprintf("SELECT * from req_data where plant='$plant'");

//execute query
$result1 = $mysqli1->query($query1);

//loop through the returned data
$data1 = array();
foreach ($result1 as $row1) {
	$data1[] = $row1;
//print_r($data);
}
?>
<?php 
session_start();
?>
<?php 
if (!$_SESSION['username']) {
	header("Location:index.php");
}
?>
<?php
//require("db.php");
$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

if(!$mysqli){
	die("Connection failed: " . $mysqli->error);
}

//query to get data from the table
$query = sprintf("SELECT temp,hum,water,light FROM data where id=(select max(id) from data)");
$query2 = sprintf("SELECT avg(temp),avg(hum),avg(water),avg(light) FROM data");

//execute query
$result = $mysqli->query($query);
$result2 = $mysqli->query($query2);
//loop through the returned data
$data = array();
foreach ($result as $row) {
	$data[] = $row;
//print_r($data);
}	
 ?>
<!DOCTYPE html>
<html>
<head> 	
<title>DashBoard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/Chart.js"></script>
		<script type="text/javascript" src="js/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          <?php
           while($row1=mysqli_fetch_array($result2)){

             echo "['"."temperature"."',".$row1[0]."],";
             echo "['"."Humidity"."',".$row1[1]."],";
             echo "['"."Moisture"."',".$row1[2]."],";
             echo "['"."Light Intensity"."',".$row1[3]."]";
         }?>
        ]);

        var options = {
          title: 'AFTER'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
   <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Temperature',     32],
          ['Humidity',      55],
          ['Moisture',  355],
          ['Light Intensity', 32],
          ['Yield',    80]
        ]);

        var options = {
          title: 'BEFORE'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart1'));

        chart.draw(data, options);
      }
    </script>
</head>
<meta http-equiv="refresh" content="20">
<body>
<nav  class="navbar navbar-inverse navbar-fixed-left">
	<ul class="nav navbar-nav">
		<li>
			<a href="#"><?php echo "Welcome ! ".$_SESSION['username']; ?></a>
		</li>
		<li>
			<a href="temp_graph.php">Temperature Graph</a>
		</li>
		<li>
			<a href="hum_graph.php">Humidity Graph</a>
		</li>
		<li>
			<a href="water_graph.php">Moisture Graph</a>
		</li>
		<li>
			<a href="light_graph.php">Light Intensity Graph</a>
		</li>
                <li>
			<a href="logout.php">Logout!</a>
		</li>
	</ul>
</nav>
<div style="width: 100vw;height: 100vh;margin-top:-20px;background:url('img/se.jpg');background-size: 100% 100%">
	<div style="width: 100vw;height: 50vh;margin-top:-30px">
		<div style="background-size: 100% 100%; width: 50vw;height: 50vh;float: right" class="rounded">
<?php echo "<h2 style='text-transform:uppercase'>SUITABLE WEATHER CONDITION FOR &nbsp".$data1[0]['plant']."</h2>"; ?>
<?php echo "high Temperature is&nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"." above".$data1[0]['temp_high']."C"."<br>"; ?>
                    <?php echo "low Temperature is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp "."below".$data1[0]['temp_low']."C"."<br>"; ?>
                    <?php echo "Optimal Temperature is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data1[0]['temp_opt']."C"."<br>"; ?>
<?php echo "high humidity is&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."above ".$data1[0]['hum_high']."%"."<br>"; ?>
<?php echo "low Humidity is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."below".$data1[0]['hum_low']."%"."<br>"; ?>
<?php echo "optimal Humidity is  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data1[0]['hum_opt']."%"."<br>"; ?>
  <?php echo "high Moisture Level is&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."above".$data1[0]['water_high']."<br>"; ?>
                    <?php echo "Low Moisture Level is&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."below".$data1[0]['water_low']."<br>"; ?>
                    <?php echo "Optimal Moisture Level is&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data1[0]['water_opt']."<br>"; ?>
<?php echo "high Light Intensity is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."above".$data1[0]['light_high']."hours"."<br>"; ?>
<?php echo "Low Light Intensity is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"."below".$data1[0]['light_low']."hours"."<br>"; ?>
<?php echo "optimal Light Intensity is&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data1[0]['light_opt']."hours"; ?>
	
       
</div>
	<div  style="background-size: 100% 100%;width: 50vw;height:50vh;float: left">
               <h2>WEATHER CONDITION IN FIELD</h2>
	        <?php echo "<center>Current Temperature is &nbsp&nbsp &nbsp &nbsp".$data[0]['temp']."<br>"; ?>
                  <?php echo "Current Light Intensity is &nbsp &nbsp &nbsp".$data[0]['light']."<br>"; ?>
        	 <?php echo "Current Humidity is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data[0]['hum']."<br>"; ?> 
                 <?php  echo "Current Moisture is &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$data[0]['water']."</center><br>"; ?>
       
</div>
	<div style="width: 100vw;height: 50vh;float: top">
       			<div  style="background-size: 100% 100%;width: 50vw;height: 50vh;float: left">
                   <div id="piechart1" style="width: 40vw; height: 35vh;padding-left:60px;"></div>
</div>

	<div style="background-size: 100% 100%;width: 50vw;height: 50vh;float:left">
                <div id="piechart" style="width: 40vw; height: 35vh;float:left;"></div>
       	</div>
	</div>
</div>
</body>
</html>
