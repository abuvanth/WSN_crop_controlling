<?php
if(isset($_POST['get_option']))
{
 $host = 'localhost';
 $user = 'root';
 $pass = 'abu';
 $db=mysqli_connect($host, $user, $pass,'demo');

 $state = $_POST['get_option'];
 $find=mysqli_query($db,"select city from places where state='$state'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['city']."</option>";
 }
 exit;
}
?>
