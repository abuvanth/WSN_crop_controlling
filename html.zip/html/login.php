<?php
session_start();
$username=$_POST['user'];
$password=$_POST['pass'];

if($username && $password)
{
$db=mysqli_connect("localhost","root","abu","sensor");
$query="select * from login where user='$username'";
$result=mysqli_query($db,$query);
while ($row=mysqli_fetch_array($result)) {
$dbuser=$row['user'];
$dbpass=$row['pass'];
}
if ($username==$dbuser && $password==$dbpass) {
	$_SESSION['username']=$username;
	header("Location:dashboard.php");
}
else
    die("user does not exist");
}
else 
	die("pls enter username and password");
mysqli_close($db);
?>
