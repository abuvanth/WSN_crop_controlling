<?php
session_start();
?>
<?php 
if (!$_SESSION['username']) {
	header("Location:index.php");
}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>ChartJS - BarGraph</title>
		<style type="text/css">
			#chart-container {
				width: 1000px;
				height: auto;
			}
		</style>
	</head>
<meta http-equiv="refresh" content="20" >
<center>
	<body>
<a href="temp_graph1.php"><h1>Date Interval Temperature Graph</h1></a>
<h1>Temperature Graph</h1>
		<div id="chart-container">
			<canvas id="mytemp"></canvas>
		</div>

		<!-- javascript -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/Chart.min.js"></script>
		<script type="text/javascript" src="js/temp.js"></script>
	</body>
</center>
</html>
