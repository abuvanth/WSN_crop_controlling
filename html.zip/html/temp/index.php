<html>
<head>
<style type="text/css">
			#chart-container {
				width: 1000px;
				height: auto;
			}
		</style>
 <style type="text/css">
      .demo { position: relative; }
      .demo i {
        position: absolute; bottom: 10px; right: 24px; top: auto; cursor: pointer;
      }
      </style>
<link href="bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" media="all" href="daterangepicker.css" />
<link rel="stylesheet" type="text/css" href="select_style.css">
<!--<script type="text/javascript" src="jquery.js"></script>-->
<script type="text/javascript">
function fetch_select(val)
{
 $.ajax({
		url: "http://localhost/temp.php",
               data: {
              date:val
                       },
		method: "GET",
		success: function(data) {
			console.log(data);
			var time1 = [];
			var temp1 = [];

			for(var i in data) {
				time1.push("Time " + data[i].time);
				temp1.push(data[i].temp);
			}

			var chartdata = {
				labels: time1,
				datasets : [
					{
						label: 'Temperature',
						backgroundColor: 'rgba(0, 255, 0, 0.3)',
						borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						data: temp1
					}
				]
			};

			var ctx = $("#mytemp");

			var barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
}

</script>

</head>
<body>
<div class="container">
<input type="text" name="daterange">
</div>

<p id="heading">Dynamic Select Option Menu Using Ajax and PHP</p>
<center>
<div id="chart-container">
			<canvas id="mytemp"></canvas>
		</div>

		<!-- javascript -->
		
		<script type="text/javascript" src="js/Chart.min.js"></script>
                <script type="text/javascript" src="js/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
<script src="daterangepicker.js"></script>
<script src="moment.min.js"></script>

 <select onchange="fetch_select(this.value);">
  <option>Select state</option>
  <?php
  $host = 'localhost';
  $user = 'root';
  $pass = 'abu';
  $db=mysqli_connect($host, $user, $pass,'sensor');

  $select=mysqli_query($db,"select date from data");
  while($row=mysqli_fetch_array($select))
  {
   echo "<option>".$row['date']."</option>";
  }
 ?>
 </select>
<script>
$('input[name="daterange"]').daterangepicker(
{
    locale: {
      format: 'YYYY-MM-DD'
    },
    startDate: '2013-01-01',
    endDate: '2013-12-31'
}, 
function(start, end, label) {
    alert("A new date range was chosen: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
});
</script>
</div>     
</center>
</body>
</html>
