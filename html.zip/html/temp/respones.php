<?php
  // File: response.php

  // Get POST gender value
  $date = $_POST["date_data"];

  // Connect to the database
  // replace the parameters with your proper credentials
  $connection = mysqli_connect("localhost", "root", "abu", "sensor");

  // Query to run
  $query = mysqli_query($connection,
           "SELECT time,temp FROM data WHERE date ='$date'");

  // Create empty array to hold query results
  $someArray = [];

  // Loop through query and push results into $someArray;
  while ($row = mysqli_fetch_assoc($query)) {
    array_push($someArray, [
      'temp'   => $row['temp'],
      'time' => $row['time']
    ]);
  }

  // Convert the Array to a JSON String and echo it
  $someJSON = json_encode($someArray);
  echo $someJSON;
?>


