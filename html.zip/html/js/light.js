$(document).ready(function(){
	$.ajax({
		url: "light.php",
		method: "GET",
		success: function(data) {
			console.log(data);
			var time1 = [];
			var temp1 = [];

			for(var i in data) {
				time1.push("Time " + data[i].time);
				temp1.push(data[i].light);
			}

			var chartdata = {
				labels: time1,
				datasets : [
					{
						label: 'Light Indensity',
						backgroundColor: 'rgba(0, 255, 0, 0.3)',
						borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						data: temp1
					}
				]
			};

			var ctx = $("#mylight");

			var barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
});
