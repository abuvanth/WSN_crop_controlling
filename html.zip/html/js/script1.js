$(document).ready(function(){
	var ctx = $("#mycanva1").get(0).getContext("2d");

	var data = [
		{
			value: 31,
			color: "cornflowerblue",
			highlight: "lightskyblue",
			label: "Temperature"
		},
		{
			value: 55,
			color: "lightgreen",
			highlight: "yellowgreen",
			label: "Humidity"
		},
		{
			value: 31,
			color: "orange",
			highlight: "skyblue",
			label: "Light"
		}
,
		{
			value: 251,
			color: "yellow",
			highlight: "darkorange",
			label: "water"
		}
,
		{
			value: 80,
			color: "green",
			highlight: "blue",
			label: "yield"
		}
	];

	var chart = new Chart(ctx).Doughnut(data);
});
