<?php
$username=$_POST['user'];
$password=$_POST['pass'];
$email=$_POST['email'];
$phno=$_POST['phno'];
if($username && $password && $email && $phno)
{
$db=mysqli_connect("localhost","root","abu","sensor");
$query1="select * from login where user='$username'";
$result=mysqli_query($db,$query1);
$count=mysqli_num_rows($result);
if($count){
echo "user already exist";
}
else{
$query="insert into login values(0,'$username','$password','$email','$phno')";
if(mysqli_query($db,$query))
echo "Registration completed";
else
echo "Registration not completed";
}
}
else 
echo "pls fill the form completely";
mysqli_close($db);
?>
