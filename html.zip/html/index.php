<?php
session_start();
?>
<?php 
if ($_SESSION['username']) {
	header("Location:dashboard.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Myapp</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<style type="text/css">
		
		section{
			width: 100vw;height: 100vh;
		}
	</style>
</head>
<body>
<nav  class="navbar navbar-inverse navbar-fixed-top">
	<ul class="nav navbar-nav">
		<li>
			<a href="#home">Home</a>
		</li>
		<li>
			<a href="#login">Login</a>
		</li>
		<li>
			<a href="#reg">Register</a>
		</li>
		<li>
			<a href="#contact">Contact Us</a>
		</li>
	</ul>
</nav>
<section id="home" style="background: url('images/home.jpg');background-size: 100% 100%">
<center>
<br><br><br>
<h1>Remote Monitoring of Crop field using wireless Sensor Network</h1>
</center>
</section>
<section id="login" style="background: url('images/1st.jpg');background-size: 100% 100%">
<br><br><br>
<form action="login.php" method="post" class="col-md-5 col-md-offset-4" style="padding: 50px; margin-top:100px"> 
<h1 class="text-center">Login Page</h1>	
<div class="form-group">
		<input type="text" name="user" class="form-control" placeholder="username">
	</div>
	<div class="form-group">
		<input type="password" name="pass" class="form-control" placeholder="password">
	</div>
	<div>
		<input type="submit" value="Login" class="btn btn-success btn-block">
	</div>
</form>
</section>
<section id="reg" style="background: url('images/2nd.jpg');background-size: 100% 100%" >
<br><br>
<h1 class="text-center">Register Form</h1>
<form class="col-md-5 col-md-offset-4" style="padding: 50px; margin-top:100px" action="reg.php" method="post"> 
	<div class="form-group">
		<input type="text" name="user" class="form-control" placeholder="username">
	</div>
	<div class="form-group">
		<input type="text" name="email" class="form-control" placeholder="Email Id">
	</div>
	<div class="form-group">
		<input type="password" name="pass" class="form-control" placeholder="password">
	</div>
	<div class="form-group">
		<input type="password" name="pass1" class="form-control" placeholder="confirm password">
	</div>
	<div class="form-group">
		<input type="number" name="phno" class="form-control" placeholder="Phone No">
	</div>
	
	<div>
		<input type="submit" value="Register Now" class="btn btn-success btn-block">
	</div>
</form>
</section>
</body>
</html>
