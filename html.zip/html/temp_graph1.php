<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
			#chart-container {
				width: 1000px;
				height: auto;
			}
		</style>
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="daterangepicker.css">
   
    <title>Temperature Graph</title>

  </head>
  <body>
<center>
    <h1>Select Your Date Range</h1>
<div class="container">
<input type="text" name="daterange" onchange="fetch_select(this.value);">
</div>
</center>
<script type="text/javascript">
function fetch_select(val)
{
 $.ajax({
		url: "temp1.php",
               data: {
              date:val
                       },
		method: "GET",
		success: function(data) {
			console.log(data);
			var time1 = [];
			var temp1 = [];

			for(var i in data) {
				time1.push("Time " + data[i].time);
				temp1.push(data[i].temp);
			}

			var chartdata = {
				labels: time1,
				datasets : [
					{
						label: 'Temperature',
						backgroundColor: 'rgba(0, 255, 0, 0.3)',
						borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						data: temp1
					}
				]
			};

			var ctx = $("#mytemp");

			var barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
}

</script>

<script src="moment.min.js"></script>
<script src="jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
<script src="daterangepicker.js"></script>
    
<script>
$('input[name="daterange"]').daterangepicker(
{
    locale: {
      format: 'YYYY-MM-DD'
    },
    startDate: '2017-01-01',
    endDate: '2017-12-31'
}, 
function(start, end, label) {
    alert("A new date range was chosen: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
});
</script>
<center>
<div id="chart-container">
			<canvas id="mytemp"></canvas>
		</div></center>

		<!-- javascript -->
		
		<script type="text/javascript" src="js/Chart.min.js"></script>
                <script type="text/javascript" src="js/jquery.min.js"></script>

  </body>
</html>
