$(document).ready(function(){
	var ctx = $("#mycanvas").get(0).getContext("2d");
    var obj=JSON.parse('{"sensor_data":[{"temp":"31","hum":"41","water":"67","light":"55"}]}')
var temp=obj.sensor_data[0].temp;
var water=obj.sensor_data[0].water;
var light=obj.sensor_data[0].light;
	var data = [
		{
			value: 31,
			color: "cornflowerblue",
			highlight: "lightskyblue",
			label: "Temperature"
		},
		{
			value: 41,
			color: "lightgreen",
			highlight: "yellowgreen",
			label: "Humidity"
		},
		{
			value: 67,
			color: "orange",
			highlight: "darkorange",
			label: "Light"
		}
	];

	var chart = new Chart(ctx).Doughnut(data);
});
