<?php
//require("db.php");
//setting header to json
header('Content-Type: application/json');

//database
//get connection
$date=$_GET['date'];
$sdate=$date[0].$date[1].$date[2].$date[3].$date[4].$date[5].$date[6].$date[7].$date[8].$date[9];
$fdate=$date[13].$date[14].$date[15].$date[16].$date[17].$date[18].$date[19].$date[20].$date[21].$date[22];
$mysqli = new mysqli('localhost', 'root', 'abu', 'sensor');

if(!$mysqli){
	die("Connection failed: " . $mysqli->error);
}
//$date=$_GET['date'];
//query to get data from the table
$query = sprintf("SELECT time, temp FROM data where date between '$sdate' and '$fdate'");

//execute query
$result = $mysqli->query($query);

//loop through the returned data
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

//free memory associated with result
$result->close();

//close connection
$mysqli->close();

//now print the data
print json_encode($data);
