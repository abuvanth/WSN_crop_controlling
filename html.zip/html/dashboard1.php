<!DOCTYPE html>
<html>
<head> 	
<title>DashBoard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<meta http-equiv="refresh" content="20">
<body>
<nav  class="navbar navbar-inverse navbar-fixed-left">
	<ul class="nav navbar-nav">
		<li>
			<a href="#"><?php echo "Welcome ! ".$_SESSION['username']; ?></a>
		</li>
		<li>
			<a href="temp_graph.php">Temperature Graph</a>
		</li>
		<li>
			<a href="hum_graph.php">Humidity Graph</a>
		</li>
		<li>
			<a href="water_graph.php">Moisture Graph</a>
		</li>
		<li>
			<a href="light_graph.php">Light Intensity Graph</a>
		</li>
                <li>
			<a href="logout.php">Logout!</a>
		</li> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<form action="temp_info.php" method="get"> 
<select name="plant">
  <option>Select plant</option>
  <?php
  $host = 'localhost';
  $user = 'root';
  $pass = 'abu';
  $db=mysqli_connect($host, $user, $pass,'sensor');

  $select=mysqli_query($db,"select plant from req_data");
  while($row=mysqli_fetch_array($select))
  {
   echo "<option>".$row['plant']."</option>";
  }
 ?>
 </select>
<input type="submit" value="view">
</form>
	</ul>
</nav>
<div style="width: 100vw;height: 100vh;margin-top:-20px">
	<div style="width: 100vw;height: 50vh;margin-top:-30px">
		<div onclick="window.location='temp_graph.php';" style="background-size: 100% 100%; width: 50vw;height: 50vh;float: right" class="rounded text-center">
                                
</div>
	<div onclick="window.location='hum_graph.php';" style="background-size: 100% 100%;width: 50vw;height:50vh;float: left" class="text-center">	
		<?php echo "Current Temperature is"."<br>".$data[0]['temp']; ?>
                <?php echo "Current Humidity is"."<br>".$data[0]['hum']; ?>
                <?php echo "Current Moisture is"."<br>".$data[0]['water']; ?>
                 <?php echo "Current Light Intensity is"."<br>".$data[0]['light'];?>
 
</div>
	<div style="width: 100vw;height: 50vh;float: top">
				<div onclick="window.location='water_graph.php';" style="background-size: 100% 100%;width: 50vw;height: 50vh;float: right" class="text-center">
 
                 
</div>

	<div onclick="window.location='light_graph.php';" style="background-size: 100% 100%;width: 50vw;height: 50vh;float: left" class="text-center">
                 
	</div>
	</div>
</div>
</body>
</html>
