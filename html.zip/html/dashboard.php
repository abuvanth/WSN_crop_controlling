<?php 
session_start();
?>
<?php 
if (!$_SESSION['username']) {
	header("Location:index.php");
}
?>
<?php
require("db.php");
$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

if(!$mysqli){
	die("Connection failed: " . $mysqli->error);
}

//query to get data from the table
$query = sprintf("SELECT temp,hum,water,light FROM data where id=(select max(id) from data)");

//execute query
$result = $mysqli->query($query);

//loop through the returned data
$data = array();
foreach ($result as $row) {
	$data[] = $row;
//print_r($data);
}
?>
<!DOCTYPE html>
<html>
<head> 	
<title>DashBoard</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<meta http-equiv="refresh" content="20">
<body>
<nav  class="navbar navbar-inverse navbar-fixed-left">
	<ul class="nav navbar-nav">
		<li>
			<a href="#"><?php echo "Welcome ! ".$_SESSION['username']; ?></a>
		</li>
		<li>
			<a href="temp_graph.php">Temperature Graph</a>
		</li>
		<li>
			<a href="hum_graph.php">Humidity Graph</a>
		</li>
		<li>
			<a href="water_graph.php">Moisture Graph</a>
		</li>
		<li>
			<a href="light_graph.php">Light Intensity Graph</a>
		</li>
                <li>
			<a href="logout.php">Logout!</a>
		</li>
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<form action="temp_info1.php" method="get"> 
<select name="plant">
  <option>Select plant</option>
  <?php
  $host = 'localhost';
  $user = 'root';
  $pass = 'abu';
  $db=mysqli_connect($host, $user, $pass,'sensor');

  $select=mysqli_query($db,"select plant from req_data");
  while($row=mysqli_fetch_array($select))
  {
   echo "<option>".$row['plant']."</option>";
  }
 ?>
 </select>
<input type="submit" value="view">
</form>
	</ul>
</nav>
<div style="width: 100vw;height: 100vh;margin-top:-20px">
	<div style="width: 100vw;height: 50vh;margin-top:-30px">
		<div onclick="window.location='temp_graph.php';" style="background:url('img/corn.png');background-size: 100% 100%; width: 50vw;height: 50vh;float: right" class="rounded text-center">
               <?php echo "<h1>Current Temperature is</h1>"."<br><h1>".$data[0]['temp']."</h1>"; ?>
                 
</div>
	<div onclick="window.location='hum_graph.php';" style="background:url('img/banana.jpg');background-size: 100% 100%;width: 50vw;height:50vh;float: left" class="text-center">	
		 <?php echo "<h1>Current Humidity is</h1>"."<br><h1>".$data[0]['hum']."</h1>"; ?>
</div>
	<div style="width: 100vw;height: 50vh;float: top">
				<div onclick="window.location='water_graph.php';" style="background:url('img/sugarcane.jpg');background-size: 100% 100%;width: 50vw;height: 50vh;float: right" class="text-center">
 <?php echo "<h1>Current Moisture is</h1>"."<br><h1>".$data[0]['water']."</h1>"; ?>
                 
</div>

	<div onclick="window.location='light_graph.php';" style="background:url('img/rice-1-psd-0.jpg');background-size: 100% 100%;width: 50vw;height: 50vh;float: left" class="text-center">
                  <?php echo "<h1>Current Light Intensity is</h1>"."<br><h1>".$data[0]['light']."</h1>"; ?>
	</div>
	</div>
</div>
</body>
</html>
